const CONFIG = {
    titleWeb: "Chao Cau",
    introTitle: 'Hong bic la ai',
    introDesc: `dkm cau ngu nhu tro`,
    btnIntro: '^^HiHi^^',
    title: 'cau nhin ngu quaa',
    desc: 'cut dy ',
    btnYes: 'hok be oi ',
    btnNo: 'o k e',
    question: 'sao cau hok cut dii',
    btnReply: 'Gửi cho bạn <3',
    reply: 'tai to thich cau',
    mess: 'to biet ma',
    messDesc: '',
    btnAccept: '\bie',
    messLink: 'https://www.facebook.com/messages/t/100034537841831' //link mess của các bạn. VD: https://m.me/nam.nodemy
}
